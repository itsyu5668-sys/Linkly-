export { default } from "../../../../app.dub.co/(auth)/login/page";
