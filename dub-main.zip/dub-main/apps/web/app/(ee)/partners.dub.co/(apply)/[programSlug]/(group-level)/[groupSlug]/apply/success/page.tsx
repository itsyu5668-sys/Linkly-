export { default } from "../../../../(default)/apply/success/page";
