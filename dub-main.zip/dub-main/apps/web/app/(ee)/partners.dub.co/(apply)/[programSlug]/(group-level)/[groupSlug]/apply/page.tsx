export { default } from "../../../(default)/apply/page";
