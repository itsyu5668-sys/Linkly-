export { default, generateMetadata } from "../../(default)/layout";
