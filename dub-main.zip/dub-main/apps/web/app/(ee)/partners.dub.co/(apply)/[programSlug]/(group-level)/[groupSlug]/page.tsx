export { default } from "../../(default)/page";
