export { default } from "app/app.dub.co/(auth)/unsubscribe/[token]/page";
