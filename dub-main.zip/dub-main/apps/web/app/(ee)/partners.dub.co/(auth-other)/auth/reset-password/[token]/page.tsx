export { default } from "app/app.dub.co/(auth)/auth/reset-password/[token]/page";
