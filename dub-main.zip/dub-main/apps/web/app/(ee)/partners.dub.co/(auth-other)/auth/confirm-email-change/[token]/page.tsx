export { default } from "app/app.dub.co/(auth)/auth/confirm-email-change/[token]/page";
