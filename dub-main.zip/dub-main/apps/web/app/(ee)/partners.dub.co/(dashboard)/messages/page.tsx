import { PartnerMessagesPageClient } from "./page-client";

export default function PartnerMessages() {
  return <PartnerMessagesPageClient />;
}
