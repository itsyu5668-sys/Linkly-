export { default } from "app/app.dub.co/(dashboard)/account/settings/page";
