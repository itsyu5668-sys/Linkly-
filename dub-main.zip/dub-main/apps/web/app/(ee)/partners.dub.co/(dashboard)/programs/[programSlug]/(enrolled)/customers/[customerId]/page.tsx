import { ProgramCustomerPageClient } from "./page-client";

export default function ProgramCustomer() {
  return <ProgramCustomerPageClient />;
}
