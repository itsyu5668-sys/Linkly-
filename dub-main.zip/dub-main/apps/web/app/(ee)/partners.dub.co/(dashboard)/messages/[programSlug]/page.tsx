import { PartnerMessagesProgramPageClient } from "./page-client";

export default function PartnerMessagesProgramPage() {
  return <PartnerMessagesProgramPageClient />;
}
