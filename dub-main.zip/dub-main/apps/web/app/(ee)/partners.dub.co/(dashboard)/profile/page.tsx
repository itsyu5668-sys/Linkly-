import { ProfileSettingsPageClient } from "./page-client";

export default function ProfileSettingsPage() {
  return <ProfileSettingsPageClient />;
}
