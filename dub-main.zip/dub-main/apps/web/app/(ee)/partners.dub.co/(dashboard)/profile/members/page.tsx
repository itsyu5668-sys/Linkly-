import { ProfileMembersPageClient } from "./page-client";

export default function ProfileMembersPage() {
  return <ProfileMembersPageClient />;
}
