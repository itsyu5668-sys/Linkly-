export { default } from "../../../(generic)/register/page";
