export {
  default,
  generateMetadata,
  generateStaticParams,
} from "../../(generic)/layout";
