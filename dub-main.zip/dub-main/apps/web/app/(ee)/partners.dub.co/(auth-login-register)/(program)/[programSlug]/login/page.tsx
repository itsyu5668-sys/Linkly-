export { default } from "../../../(generic)/login/page";
