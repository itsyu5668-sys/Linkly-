# Security Policy

## Supported Versions

All versions of Dub are currently being supported with security updates.

## Reporting a Vulnerability

To report a vulnerability, send an email to security@dub.co.

We will respond within 48 hours acknowledging your report with details about next steps and potential rewards/compensation for responsible disclosure.
